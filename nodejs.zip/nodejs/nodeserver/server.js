var express = require("express");
var app = express();

app.listen(9091);
app.use(express.static(__dirname+'/public'));//npm install http/express
app.get('/getMsg',function(request,response)
{
response.end("Hello World from Node!");
}
)
// Console will print the message
console.log('Server running at 9091/')