var express = require("express");
var app = express();

app.listen(9091);
app.use(express.static(__dirname+'/public'));
app.get('/getMsg',function(request,response)
{
response.end('Hello World from Node');
}
)
// Console will print the message
console.log('Server running at http://127.0.0.1:8081/')