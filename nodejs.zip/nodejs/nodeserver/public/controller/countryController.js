app.controller('stateController',function($scope,$http){
				$scope.states=['Karanataka','AP','Kerla', 'TN'];
			});